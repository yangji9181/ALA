MAX_LEN = 300
neg_table_size = 1000000
NEG_SAMPLE_POWER = 0.75
batch_size = 64
num_epoch = 200
embed_size = 200
lr = 1e-3
