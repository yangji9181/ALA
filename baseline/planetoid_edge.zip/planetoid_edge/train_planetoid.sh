#!/bin/sh

python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train1.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test1.txt"
python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train2.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test2.txt"
python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train3.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test3.txt"
python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train4.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test4.txt"
python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train5.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test5.txt"

python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train1.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test1.txt"
python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train2.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test2.txt"
python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train3.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test3.txt"
python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train4.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test4.txt"
python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train5.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test5.txt"

python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train1.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test1.txt"
python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train2.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test2.txt"
python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train3.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test3.txt"
python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train4.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test4.txt"
python test_ind.py --rel_train_path "../author_graph_dataset/5-folder-rel/rel-train5.txt" --rel_test_path "../author_graph_dataset/5-folder-rel/rel-test5.txt"